from django.db import models
from django.contrib.auth.models import User

class Equipo(models.Model):
    nombre = models.CharField(max_length=100)
    miembros = models.ManyToManyField(User, related_name='equipos')

    def __str__(self):
        return self.nombre

class Proyecto(models.Model):
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField()
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    equipo = models.ForeignKey(Equipo, on_delete=models.SET_NULL, null=True, blank=True, related_name='proyectos')
    es_individual = models.BooleanField(default=False)

    def __str__(self):
        return self.nombre

class Tarea(models.Model):
    proyecto = models.ForeignKey(Proyecto, on_delete=models.CASCADE, related_name='tareas')
    descripcion = models.TextField()
    duracion = models.DurationField()
    responsable = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='tareas_responsable')
    ejecutor = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='tareas_ejecutor')

    def __str__(self):
        return f"Tarea de {self.proyecto.nombre}"