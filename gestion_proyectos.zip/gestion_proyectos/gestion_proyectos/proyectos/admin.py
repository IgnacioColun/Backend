from django.contrib import admin
from .models import Equipo, Proyecto, Tarea

admin.site.register(Equipo)
admin.site.register(Proyecto)
admin.site.register(Tarea)