from django.urls import path
from . import views

urlpatterns = [
    path('', views.lista_proyectos, name='lista_proyectos'),
    path('proyecto/<int:pk>/', views.detalle_proyecto, name='detalle_proyecto'),
    path('proyecto/nuevo/', views.crear_proyecto, name='crear_proyecto'),
    path('proyecto/<int:proyecto_id>/tarea/nueva/', views.crear_tarea, name='crear_tarea'),
    path('proyectos/crear_usuario.html', views.crear_usuario, name='crear_usuario'),
    path('proyectos/crear_equipo.html', views.crear_equipo, name='crear_equipo'),
    path('proyecto/<int:pk>/eliminar/', views.eliminar_proyecto, name='eliminar_proyecto'),
    path('equipo/<int:pk>/eliminar/', views.eliminar_equipo, name='eliminar_equipo'),
    path('tarea/<int:pk>/eliminar/', views.eliminar_tarea, name='eliminar_tarea'),
]