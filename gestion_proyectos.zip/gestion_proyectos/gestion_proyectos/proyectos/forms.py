from django import forms
from django.contrib.auth.models import User
from .models import Equipo, Proyecto, Tarea
from django.core.exceptions import ValidationError

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username','first_name']

class EquipoForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ['nombre'] 

class ProyectoForm(forms.ModelForm):
    class Meta:
        model = Proyecto
        fields = ['nombre', 'descripcion', 'fecha_inicio', 'fecha_fin', 'equipo', 'es_individual']
    
    def clean(self):
        cleaned_data = super().clean()
        es_individual = cleaned_data.get("es_individual")
        equipo = cleaned_data.get("equipo")

        if es_individual and equipo:
            raise ValidationError("Un proyecto no puede ser individual y tener un equipo asignado al mismo tiempo.")
        
        return cleaned_data
    

class TareaForm(forms.ModelForm):
    class Meta:
        model = Tarea
        fields = ['descripcion', 'duracion', 'responsable', 'ejecutor']